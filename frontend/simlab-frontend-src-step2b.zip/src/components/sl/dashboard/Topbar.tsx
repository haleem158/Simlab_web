import Link from "next/link";
import { Icon } from "../Icon";
import { NewRunMenu } from "../NewRunMenu";

export function Topbar() {
  return (
    <div className="tb">
      <NewRunMenu />
      <div className="r">
        <Link className="sb2" href="/">
          Home
          <Icon n="dash" style={{ width: 16, height: 16 }} />
        </Link>
      </div>
    </div>
  );
}
