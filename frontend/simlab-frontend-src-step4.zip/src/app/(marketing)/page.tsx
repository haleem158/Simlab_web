import { LandingPage } from "../../components/sl/landing/LandingPage";
import { Sections } from "../../components/sl/landing/Sections";

export default function Home() {
  return (
    <div className="slab">
      <LandingPage />
      <Sections />
    </div>
  );
}
