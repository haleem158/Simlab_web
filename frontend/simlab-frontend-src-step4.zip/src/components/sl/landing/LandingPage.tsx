import Link from "next/link";
import { Icon } from "../Icon";
import { Logo } from "../Logo";
import { CountUp } from "../CountUp";

const API = process.env.NEXT_PUBLIC_API_URL?.trim() || "http://localhost:8000";

export function LandingPage() {
  return (
    <>
      <div className="nav">
        <div className="logo">
          <Logo height={36} />
          Simlab
        </div>
        <div className="links">
          <Link href="/token-supply">Token supply</Link>
          <Link href="/vesting">Vesting</Link>
          <Link href="/token-impact">Price impact</Link>
          <a href={`${API}/api/docs`} target="_blank" rel="noopener noreferrer">
            API docs
          </a>
        </div>
        <div className="navr">
          <Link className="btn coral" href="/dashboard">
            Open dashboard
          </Link>
        </div>
      </div>
      <div className="hero">
        <h1>Design token economies that last</h1>
        <p>
          Model supply, demand, and holder behavior before you deploy. Run
          vesting, price impact, and Monte Carlo simulations, all in one unified
          platform.
        </p>
        <div className="cta">
          <Link className="btn coral" href="/token-supply">
            Start Simulation
          </Link>
          <a className="btn ghost" href="#why-it-matters">
            Learn Why It Matters
          </a>
        </div>
        <div className="prod">
          <div className="ps">
            <div className="logo">
              <Logo height={26} />
              Simlab
            </div>
            <div className="pi">
              <Icon n="dash" />
              Dashboard
            </div>
            <div className="pi on">
              <Icon n="coins" />
              Token supply
            </div>
            <div className="pi">
              <Icon n="cal" />
              Vesting
            </div>
            <div className="pi">
              <Icon n="down" />
              Price impact
            </div>
          </div>
          <div className="pm">
            <div className="ph">
              <div>
                <h3>Token Supply Simulator</h3>
                <small>
                  Circulating, staked and burned supply over 5 years
                </small>
              </div>
              <div className="ctl">
                <div className="sel">Sample data</div>
              </div>
            </div>
            <div className="kpis">
              <div className="kpi">
                <div className="l">Final circulating</div>
                <div className="v">
                  <CountUp to={1.24} dec={2} pre="" suf="B" />
                </div>
                <div className="s">+211% vs. start</div>
              </div>
              <div className="kpi">
                <div className="l">Final burned</div>
                <div className="v">
                  <CountUp to={48.2} dec={1} pre="" suf="M" />
                </div>
                <div className="s">4.8% of supply</div>
              </div>
              <div className="kpi">
                <div className="l">Final staked</div>
                <div className="v">
                  <CountUp to={613} dec={0} pre="" suf="M" />
                </div>
                <div className="s">49.3% of circulating</div>
              </div>
              <div className="kpi">
                <div className="l">Final price</div>
                <div className="v">
                  <CountUp to={0.84} dec={2} pre="$" suf="" />
                </div>
                <div className="s">+40.0% vs. start</div>
              </div>
              <div className="kpi">
                <div className="l">Horizon</div>
                <div className="v">
                  <CountUp to={5} dec={0} pre="" suf=" years" />
                </div>
                <div className="s">Monte Carlo, 100 runs</div>
              </div>
            </div>
            <div className="row2">
              <div className="cardp">
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                >
                  <div>
                    <h4>Circulating supply</h4>
                    <small>Sample projection by quarter</small>
                  </div>
                  <div className="sel" style={{ height: 30, fontSize: 12 }}>
                    5 years
                  </div>
                </div>
                <div className="bars">
                  <b style={{ height: "38%" }} />
                  <b style={{ height: "46%" }} />
                  <b style={{ height: "54%" }} />
                  <b style={{ height: "52%" }} />
                  <b style={{ height: "60%" }} />
                  <b style={{ height: "72%" }} />
                  <b style={{ height: "80%" }} />
                  <b style={{ height: "78%" }} />
                  <b style={{ height: "86%" }} />
                  <b style={{ height: "92%" }} />
                  <b style={{ height: "96%" }} />
                  <b style={{ height: "100%" }} />
                </div>
              </div>
              <div className="cardp">
                <div>
                  <h4>Supply split</h4>
                  <small>Share of all tokens issued</small>
                </div>
                <div className="donutw">
                  <svg
                    width="120"
                    height="120"
                    viewBox="0 0 42 42"
                    style={{ transform: "rotate(-90deg)" }}
                    aria-hidden="true"
                  >
                    <circle
                      cx="21"
                      cy="21"
                      r="15.9"
                      fill="none"
                      stroke="#141416"
                      strokeWidth="5"
                    />
                    <circle
                      cx="21"
                      cy="21"
                      r="15.9"
                      fill="none"
                      stroke="#6d4cf5"
                      strokeWidth="5"
                      pathLength="100"
                      strokeDasharray="47.4 52.6"
                      strokeDashoffset="0"
                    />
                    <circle
                      cx="21"
                      cy="21"
                      r="15.9"
                      fill="none"
                      stroke="#38bdf8"
                      strokeWidth="5"
                      pathLength="100"
                      strokeDasharray="48.9 51.1"
                      strokeDashoffset="-47.4"
                    />
                    <circle
                      cx="21"
                      cy="21"
                      r="15.9"
                      fill="none"
                      stroke="#f87171"
                      strokeWidth="5"
                      pathLength="100"
                      strokeDasharray="3.7 96.3"
                      strokeDashoffset="-96.3"
                    />
                  </svg>
                  <div className="legend">
                    <div>
                      <i style={{ background: "#6d4cf5" }} />
                      Liquid
                      <span>47.4%</span>
                    </div>
                    <div>
                      <i style={{ background: "#38bdf8" }} />
                      Staked
                      <span>48.9%</span>
                    </div>
                    <div>
                      <i style={{ background: "#f87171" }} />
                      Burned
                      <span>3.7%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
