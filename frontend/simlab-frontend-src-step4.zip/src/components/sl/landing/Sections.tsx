import Link from "next/link";
import { CountUp } from "../CountUp";
import { Icon } from "../Icon";
import { Logo } from "../Logo";

const API = process.env.NEXT_PUBLIC_API_URL?.trim() || "http://localhost:8000";

const STATS = [
  {
    to: 90,
    pre: "",
    suf: "%",
    label: "Startup Failure Rate",
    note: "Poor tokenomics is a leading cause",
  },
  {
    to: 4000,
    pre: "",
    suf: "+",
    label: "Dead Coins Tracked",
    note: "65% from broken incentive models",
  },
  {
    to: 790,
    pre: "$",
    suf: "M",
    label: "Lost in 2022 Alone",
    note: "From tokenomics-related failures",
  },
];

const FAILS = [
  {
    title: "Misaligned Incentives",
    text: "Unsustainable yields attract mercenary capital. Teams and VCs dump at unlock.",
  },
  {
    title: "Hyperinflation",
    text: "Excessive emissions and farming rewards create runaway supply growth.",
  },
  {
    title: "Broken Token Design",
    text: "No utility, weak burns, over-reliance on airdrops create boom-bust cycles.",
  },
  {
    title: "No Stress Testing",
    text: "Founders don't model edge cases or test sustainability under different scenarios.",
  },
];

const SIMS = [
  {
    href: "/token-supply",
    icon: "coins",
    color: "#3b2f7a",
    title: "Token Supply Simulator",
    text: "Model inflation, staking, burning, and vesting over time. Run Monte Carlo simulations to test supply stability under uncertainty.",
    points: [
      "Emission schedules & decay rates",
      "Staking participation curves",
      "Burn mechanism modeling",
      "Price impact estimation",
    ],
  },
  {
    href: "/vesting",
    icon: "cal",
    color: "#7c2d2d",
    title: "Vesting Simulator",
    text: "Visualize token unlocks for team, investors, and community. Test cliff schedules and governance locks to prevent sell pressure.",
    points: [
      "Multi-stakeholder allocations",
      "Cliff & linear vesting curves",
      "Governance vs. liquid splits",
      "Monthly inflation tracking",
    ],
  },
  {
    href: "/token-impact",
    icon: "down",
    color: "#5b35c9",
    title: "Price Impact Model",
    text: "Estimate how demand growth and supply changes affect token price. Calibrate models to real market data.",
    points: [
      "Demand vs. supply dynamics",
      "Transaction & staking growth",
      "Price sensitivity analysis",
      "CSV data import",
    ],
  },
];

const FEATURES = [
  {
    icon: "line",
    title: "Visual Analytics",
    text: "Interactive charts showing supply curves, inflation rates, and price trajectories.",
  },
  {
    icon: "flask",
    title: "Monte Carlo Simulation",
    text: "Run stochastic models with confidence intervals for uncertainty analysis.",
  },
  {
    icon: "dl",
    title: "CSV Import/Export",
    text: "Upload your own data or download results for deeper analysis.",
  },
  {
    icon: "target",
    title: "Preset Scenarios",
    text: "Start with Bitcoin, Ethereum, or DeFi templates and customize.",
  },
];

export function Sections() {
  return (
    <>
      <section className="sec" id="why-it-matters">
        <h2 className="sh">The Token Economy Crisis</h2>
        <p className="ssub">Real numbers from protocol failures</p>
        <div className="stats">
          {STATS.map((s) => (
            <div className="stat" key={s.label}>
              <div className="num">
                <CountUp to={s.to} dec={0} pre={s.pre} suf={s.suf} />
              </div>
              <div className="sl1">{s.label}</div>
              <div className="sl2">{s.note}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="sec">
        <h2 className="sh">Why Protocols Fail</h2>
        <p className="ssub wide">
          Token economies are <b>complex, non-deterministic systems</b> where
          supply, demand, user behavior, and governance interact dynamically.
          Most founders launch with assumptions that collapse under real-world
          stress.
        </p>
        <div className="fails">
          {FAILS.map((f) => (
            <div className="fail" key={f.title}>
              <div className="fx">
                <Icon n="x" style={{ width: 16, height: 16 }} />
              </div>
              <div>
                <h4>{f.title}</h4>
                <p>{f.text}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="sec">
        <div className="solve">
          <h3>The Solution: Model Before You Deploy</h3>
          <p>
            Simlab turns complex token dynamics into testable, visual
            simulations, so you can design for sustainability, not speculation.
          </p>
          <Link className="btn coral" href="/token-supply">
            Start Simulation
          </Link>
        </div>
      </section>

      <section className="sec" id="simulators">
        <h2 className="sh">Three Core Simulators</h2>
        <p className="ssub">
          Model every critical dimension of your token economy
        </p>
        <div className="sims">
          {SIMS.map((s) => (
            <Link className="sim" href={s.href} key={s.href}>
              <div className="sic" style={{ background: s.color }}>
                <Icon n={s.icon} style={{ width: 22, height: 22 }} />
              </div>
              <h4>{s.title}</h4>
              <p>{s.text}</p>
              <ul>
                {s.points.map((p) => (
                  <li key={p}>{p}</li>
                ))}
              </ul>
              <span className="open">
                Open simulator
                <Icon n="ur" style={{ width: 15, height: 15 }} />
              </span>
            </Link>
          ))}
        </div>
      </section>

      <section className="sec">
        <h2 className="sh">Built for Serious Teams</h2>
        <div className="feats">
          {FEATURES.map((f) => (
            <div className="feat2" key={f.title}>
              <div className="fic">
                <Icon n={f.icon} style={{ width: 20, height: 20 }} />
              </div>
              <h4>{f.title}</h4>
              <p>{f.text}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="foot">
        <div className="fl1">
          <div className="logo" style={{ fontSize: 20 }}>
            <Logo height={30} />
            Simlab
          </div>
          <p>Evidence-based token design</p>
        </div>
        <nav className="fl2" aria-label="Footer">
          <Link href="/token-supply">Token supply</Link>
          <Link href="/vesting">Vesting</Link>
          <Link href="/token-impact">Price impact</Link>
          <a href={`${API}/api/docs`} target="_blank" rel="noopener noreferrer">
            API docs
          </a>
        </nav>
        <div className="fl3">
          © {new Date().getFullYear()} Simlab. Empowering data-driven token
          design.
        </div>
      </footer>
    </>
  );
}
